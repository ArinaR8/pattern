from flask import Flask, render_template, request, url_for, redirect
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user
from datetime import datetime
from random import randint
from DataBase.crud import Manager
import DataBase.orm_models as orm_models


manager = Manager()


app = Flask(__name__)


app.config.update(
    SECRET_KEY='WOW SUCH SECRET'
    )

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


class User(UserMixin):
    def __init__(self, id):
        self.id = id


@login_manager.user_loader
def load_user(login):
    return User(login)


@app.route('/')
@login_required
def index():
    return render_template('index.html')


@app.route('/about/')
@login_required
def about():
    return render_template('about.html')


@app.route('/feedback/')
@login_required
def feedback():
    return render_template('feedback.html')


@app.route('/contacts/')
@login_required
def contacts():
    return render_template('contacts.html')


@app.route('/products/', methods=['GET', 'POST'])
@login_required
def products():
    data = manager.get_all(orm_models.products)
    for row in data:
        res = manager.get(orm_models.cart, 'id', row.id)
        if res:
            row.amount = res.amount
        else:
            row.amount = 0
    if request.method == 'POST':
        cart_data = manager.get(orm_models.cart, 'id', request.form['item_id'])
        if cart_data:
            manager.update(orm_models.cart, 'id', 'amount', request.form['item_id'], cart_data.amount+1)
        else:
            manager.add(orm_models.cart, {'id': request.form['item_id'], 'amount': 1})
    product = [{'name': 'Наушники',
                'description': 'Насыщенные басы, цвет: синиий, подсветка',
                'img': '/static/images/earbuds.jpg',
                'price': '5000 р.'},
               {'name': 'Контроллер Xbox',
                'description': 'Классический черный оригинальный',
                'img': '/static/images/kontr.webp',
                'price': '3500 р.'},
               {'name': 'Принтер Canon',
                'description': 'Цвет: белый, Тип печати: цветная',
                'img': '/static/images/pr.webp',
                'price': '50000 р.'},
               {'name': 'Колонка беспроводная',
                'description': 'Глубокий звук, Формат: портативный',
                'img': '/static/images/kol.webp',
                'price': '8000 р.'}]
    return render_template('products.html', product=data)


@app.route('/cart/')
@login_required
def cart():
    data = manager.get_all(orm_models.products)
    global_sum = 0
    data1 = []
    for row in data:
        res = manager.get(orm_models.cart, 'id', row.id)
        if res:
            row.amount = res.amount
            local_sum = int(res.amount)*int(row.price)
            global_sum += local_sum
            row.local_sum = local_sum
            data1.append(row)
    return render_template('cart.html', data=data1, global_sum=global_sum)


@app.route('/lootbox/')
@login_required
def lootbox():
    r = randint(1, 100)
    return render_template('lootbox.html', r=r)


@app.route('/product1/')
@login_required
def product1():
    r = randint(1, 5)
    end_date = datetime.strptime('14.04.2023', "%d.%m.%Y")
    date = end_date - datetime.now()
    date = f' через {date.days} дней, {date.seconds//3600} часа и {date.seconds//60 - date.seconds//3600*60} минуты'
    return render_template('product1.html', action_name="", end_date=date, r=r)


@app.route('/product2/')
@login_required
def product2():
    brands = ['Xbox', 'Canon', 'Airpods', 'Wireless']
    return render_template('product2.html', brands=brands)


@app.route('/order/', methods=['GET', 'POST'])
@login_required
def order():
    error = ""
    if request.method == 'POST':
        for key in request.form:
            if request.form[key] == "":
                error = "Заполните все поля!"
                return render_template('order.html', error=error)
        manager.add(orm_models.orders, request.form)
        data = manager.get_all(orm_models.cart)
        for row in data:
            manager.delete(orm_models.cart, 'id', row.id)
        return redirect(url_for('order_list'))
    return render_template('order.html', error=error)


@app.route('/order_list/')
@login_required
def order_list():
    data = manager.get_all(orm_models.orders)
    return render_template('order_list.html', data=data)


@app.route('/login/', methods=['POST', 'GET'])
def login():
    error = ""
    if request.method == 'POST':
        for key in request.form:
            if request.form[key] == "":
                error = "Заполните все поля!"
        if error == "":
            check = manager.get(orm_models.login, 'login', request.form['Login'])
            if check:
                if request.form["Password"] != check.password:
                    error = "Неверный пароль!"
                else:
                    user = User(login)
                    login_user(user)
                    return redirect(url_for('index'))
            else:
                error = "Неверный логин!"
    return render_template('login.html', error=error)


@app.route("/logout/")
@login_required
def logout():
    logout_user()
    return 'Пока'


@app.route("/registration/", methods=['POST', 'GET'])
def registration():
    error = ""
    if request.method == 'POST':
        for key in request.form:
            if request.form[key] == "":
                error = "Заполните все поля!"
        if error == "":
            check = manager.get(orm_models.login, 'login', request.form['login'])
            check_num = manager.get(orm_models.login, 'phone_number', request.form['phone_number'])
            check_em = manager.get(orm_models.login, 'email', request.form['email'])
            if check is None and check_num is None and check_em is None:
                if request.form["password"] != request.form['password_repit']:
                    error = "Пароли не совпадают!"
                else:
                    data = dict(request.form)
                    data.pop('password_repit')
                    manager.add(orm_models.login, data=data)
                    return redirect(url_for('login'))
            elif check:
                error = "Такоe имя пользователя уже существует!"
            elif check_num:
                error = "Этот номер уже занят!"
            else:
                error = "Эта почта уже занята!"
    return render_template('registration.html', error=error)


if __name__ == "__main__":
    app.run()
