from sqlalchemy import Column, Integer, String
from .db import Base


class products(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    description = Column(String)
    price = Column(Integer)
    photo = Column(String)

    def __repr__(self):
        return f"products(id={self.id!r}, name={self.name!r}, description={self.description!r}, " \
               f"price={self.price!r},photo={self.photo!r})"


class cart(Base):
    __tablename__ = "cart"
    id = Column(Integer, primary_key=True)
    amount = Column(Integer)

    def __repr__(self):
        return f"cart(id={self.id!r}, amount={self.amount!r})"


class login(Base):
    __tablename__ = "login"
    id = Column(Integer, primary_key=True)
    login = Column(String)
    password = Column(String)
    email = Column(String)
    phone_number = Column(String)

    def __repr__(self):
        return f"login(id={self.id!r}, login={self.login!r}, password={self.password!r}," \
               f" email={self.email!r}, phone_number={self.phone_number!r})"


class orders(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    surname = Column(String)
    address = Column(String)
    email = Column(String)
    phone_number = Column(String)
    type = Column(String)
    date = Column(String)

    def __repr__(self):
        return f"orders(id={self.id!r}, name={self.name!r}, surname={self.surname!r}," \
               f" email={self.email!r}, phone_number={self.phone_number!r}, address={self.address!r}," \
               f" type={self.type!r}, date={self.date!r})"
