from sqlalchemy.orm import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

engine = create_engine("sqlite:///DataBase/db.db", echo=False, future=True)

Base = declarative_base()

s = Session(engine)
