from .db import s


class Manager:
    s = s

    def get_all(self, table):
        q = self.s.query(table)
        data = q.all()
        return data

    def add(self, table, data):
        self.s.add(table(**data))
        self.s.commit()

    def get(self, table, key, value):
        return self.s.query(table).filter(getattr(table, key) == value).first()

    def update(self, table, key, update_key, key_value, new_value):
        self.s.query(table).filter(getattr(table, key) == key_value).update({update_key: new_value})
        self.s.commit()

    def delete(self, table, key, value):
        self.s.query(table).filter(getattr(table, key) == value).delete()
        self.s.commit()